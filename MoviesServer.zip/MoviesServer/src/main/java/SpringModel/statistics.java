package SpringModel;

public class statistics {
	private String year;
	private String month;
	private String quarter;
	private int topnumber;
	public String getYear() {
		return year;
	}
	public void setYear(String year) {
		this.year = year;
	}
	public String getMonth() {
		return month;
	}
	public void setMonth(String month) {
		this.month = month;
	}
	public String getQuarter() {
		return quarter;
	}
	public void setQuarter(String quarter) {
		this.quarter = quarter;
	}
	public int getTopnumber() {
		return topnumber;
	}
	public void setTopnumber(int topnumber) {
		this.topnumber = topnumber;
	}
}
